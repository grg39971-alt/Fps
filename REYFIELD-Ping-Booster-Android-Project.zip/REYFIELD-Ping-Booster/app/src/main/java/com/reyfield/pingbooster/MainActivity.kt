package com.reyfield.pingbooster

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import java.net.InetAddress
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var statusText: TextView
    private lateinit var resultText: TextView
    private lateinit var hostInput: EditText
    private lateinit var testButton: Button
    private lateinit var profileSpinner: Spinner

    private val bg = Color.rgb(10, 15, 28)
    private val panel = Color.rgb(20, 29, 48)
    private val accent = Color.rgb(78, 220, 173)
    private val muted = Color.rgb(165, 179, 202)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("REYFIELD", 14, accent, true))
        page.addView(label("PING BOOSTER", 29, Color.WHITE, true))
        page.addView(label("Oyun bağlantı analiz aracı", 14, muted, false).apply {
            setPadding(0, dp(4), 0, dp(20))
        })

        val statusCard = card()
        statusText = label("Bağlantı kontrol ediliyor…", 15, Color.WHITE, true)
        statusCard.addView(statusText)
        page.addView(statusCard)
        updateNetworkStatus()

        page.addView(sectionTitle("OYUN PROFİLİ"))
        profileSpinner = Spinner(this)
        val profiles = listOf("Genel test", "Block Legends", "BedWars")
        profileSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, profiles)
        profileSpinner.setPadding(dp(8), dp(8), dp(8), dp(8))
        page.addView(card().apply { addView(profileSpinner) })

        page.addView(sectionTitle("HEDEF SUNUCU"))
        hostInput = EditText(this).apply {
            setSingleLine(true)
            setText("1.1.1.1")
            setTextColor(Color.WHITE)
            setHintTextColor(muted)
            hint = "Sunucu IP veya alan adı"
            textSize = 16f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(30, 42, 64))
        }
        page.addView(card().apply { addView(hostInput) })
        page.addView(label("Not: 1.1.1.1 genel test hedefidir; oyunun gerçek sunucusu değildir. Oyunun sunucu adresini biliyorsan buraya yaz.", 12, muted, false).apply {
            setPadding(dp(2), dp(6), dp(2), dp(12))
        })

        testButton = Button(this).apply {
            text = "BAĞLANTI TESTİNİ BAŞLAT"
            isAllCaps = false
            textSize = 15f
            setTextColor(bg)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setOnClickListener { runTest() }
        }
        page.addView(testButton, LinearLayout.LayoutParams(-1, dp(54)))

        page.addView(sectionTitle("TEST SONUÇLARI"))
        val resultCard = card()
        resultText = label("Henüz test yapılmadı.\n\nBaşlamak için yukarıdaki butona dokun.", 15, Color.WHITE, false)
        resultText.setLineSpacing(dp(7).toFloat(), 1f)
        resultCard.addView(resultText)
        page.addView(resultCard)

        page.addView(sectionTitle("DAHA DÜŞÜK GECİKME İÇİN"))
        val tips = card()
        tips.addView(label(
            "• Wi-Fi kullanıyorsan modeme yakın dur.\n" +
            "• İndirme ve video akışlarını test sırasında durdur.\n" +
            "• 5 GHz Wi-Fi, yakın mesafede genellikle daha az parazit sunar.\n" +
            "• Oyun içindeki bölgeyi sana en yakın sunucu olarak seç.\n" +
            "• VPN kullanıyorsan kapatıp sonucu tekrar karşılaştır.",
            14, muted, false
        ))
        page.addView(tips)
        page.addView(label(
            "Gerçekçi ölçüm: Bu uygulama TCP bağlantı gecikmesini ölçer. Android uygulaması tek başına oyun sunucusunun rotasını değiştiremez veya her bağlantıyı 8 ms'ye indiremez.",
            12, muted, false
        ).apply { setPadding(dp(2), dp(18), dp(2), 0) })
    }

    private fun runTest() {
        val host = hostInput.text.toString().trim()
        if (host.isBlank() || host.contains(" ")) {
            Toast.makeText(this, "Geçerli bir sunucu adresi gir.", Toast.LENGTH_SHORT).show()
            return
        }
        testButton.isEnabled = false
        testButton.text = "TEST EDİLİYOR…"
        resultText.text = "DNS çözümlemesi ve 5 TCP bağlantı denemesi yapılıyor…"
        executor.execute {
            val output = StringBuilder()
            try {
                val startDns = System.nanoTime()
                val address = InetAddress.getByName(host)
                val dnsMs = (System.nanoTime() - startDns) / 1_000_000.0
                val samples = mutableListOf<Long>()
                var failures = 0
                repeat(5) { index ->
                    var socket: Socket? = null
                    try {
                        socket = Socket()
                        val start = System.nanoTime()
                        socket.connect(InetSocketAddress(address, 443), 2500)
                        val elapsed = (System.nanoTime() - start) / 1_000_000
                        samples.add(elapsed)
                    } catch (_: Exception) {
                        failures++
                    } finally {
                        try { socket?.close() } catch (_: Exception) {}
                    }
                    mainHandler.post {
                        resultText.text = "Test sürüyor… ${index + 1}/5\nBaşarılı: ${samples.size}  •  Başarısız: $failures"
                    }
                }
                output.append("Hedef: $host (${address.hostAddress})\n")
                output.append("DNS çözümleme: ${"%.1f".format(dnsMs)} ms\n")
                output.append("Başarılı bağlantı: ${samples.size}/5\n")
                output.append("Paket/bağlantı başarısızlığı: ${failures * 20}%\n")
                if (samples.isNotEmpty()) {
                    val avg = samples.average()
                    val min = samples.minOrNull()!!
                    val max = samples.maxOrNull()!!
                    val jitter = if (samples.size > 1) {
                        samples.zipWithNext().map { abs(it.second - it.first).toDouble() }.average()
                    } else 0.0
                    output.append("\nTCP gecikme ortalaması: ${"%.1f".format(avg)} ms\n")
                    output.append("En düşük / en yüksek: $min / $max ms\n")
                    output.append("Jitter (ardışık fark): ${"%.1f".format(jitter)} ms\n")
                    output.append("\n${if (avg <= 30) "İyi bağlantı sonucu." else if (avg <= 80) "Orta düzey gecikme." else "Yüksek gecikme; Wi-Fi ve sunucu bölgesini kontrol et."}")
                } else {
                    output.append("\nHedefe 443/TCP bağlantısı kurulamadı. Hedef adresini veya ağını kontrol et.")
                }
            } catch (e: Exception) {
                output.append("Test başarısız: ${e.localizedMessage ?: "Adres çözümlenemedi."}")
            }
            mainHandler.post {
                resultText.text = output.toString()
                testButton.isEnabled = true
                testButton.text = "TESTİ TEKRARLA"
                updateNetworkStatus()
            }
        }
    }

    private fun updateNetworkStatus() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val kind = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobil veri"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Bilinmeyen bağlantı"
        }
        statusText.text = if (connected) "● İnternet bağlı  •  $kind" else "● İnternet bağlantısı yok"
        statusText.setTextColor(if (connected) accent else Color.rgb(255, 110, 110))
    }

    private fun sectionTitle(text: String) = label(text, 12, accent, true).apply {
        setPadding(dp(2), dp(20), 0, dp(9))
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundColor(panel)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
