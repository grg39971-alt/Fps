plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.reyfield.pingbooster"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.reyfield.pingbooster"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
