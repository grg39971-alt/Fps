# REYFIELD Ping Booster

Android için Kotlin tabanlı bağlantı analiz uygulaması.

## Özellikler
- Aktif ağ türünü gösterir (Wi-Fi / mobil veri).
- Girilen IP veya alan adı için DNS çözümleme süresini ölçer.
- Hedefin 443/TCP portuna beş bağlantı denemesi yapar.
- Ortalama, minimum, maksimum gecikme, ardışık ölçüm farkı (jitter) ve başarısız deneme oranını gösterir.
- GitHub Actions ile APK üretir.

## Önemli ölçüm notu
Bu uygulama ICMP ping veya oyunun gerçek iç ağ gecikmesini ölçmez. 443/TCP bağlantı süresi, seçilen test hedefine yapılan TCP bağlantısının süresidir. `1.1.1.1` varsayılan genel test hedefidir; Block Legends veya BedWars sunucusu değildir. Oyun sunucusunun adresini biliyorsan hedef alanına girebilirsin.

Android uygulaması tek başına diğer uygulamaların ağ rotasını değiştiremez, internet sağlayıcısının gecikmesini düşüremez veya 8 ms garanti edemez. Bu ilk sürüm root/Shizuku istemez ve sistem ayarlarını değiştirmez.

## GitHub'dan APK alma
1. Bu projeyi bir GitHub deposuna yükle.
2. `Actions` sekmesini aç.
3. `Build Android APK` iş akışının tamamlanmasını bekle.
4. Tamamlanan çalıştırmayı açıp `Artifacts` bölümünden `reyfield-ping-booster-debug` dosyasını indir.
5. ZIP'i aç; içindeki `app-debug.apk` dosyasını Android telefona kur.

## Yerel derleme
JDK 17 ve Gradle 8.9 ile proje kökünde:

```bash
gradle assembleDebug
```

APK yolu: `app/build/outputs/apk/debug/app-debug.apk`
